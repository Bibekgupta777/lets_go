class HiveTableConstant {
  HiveTableConstant._();

  static const int userTableId = 0;
  static const String userBox = 'userBox';
}
