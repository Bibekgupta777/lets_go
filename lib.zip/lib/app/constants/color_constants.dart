import 'dart:ui';

import 'package:flutter/material.dart';

const KPrimaryColor = Color(0xFF6F35A5);
const KPrimaryLightColor = Color(0xFFF1E6FF);
const kGreyColor = Color.fromARGB(147, 0, 0, 0);
const kBlueGreyColor = Color.fromARGB(149, 38, 45, 56);